import { SerenityBrowser } from '@/components/SerenityBrowser';

const Index = () => {
  return <SerenityBrowser />;
};

export default Index;
