# Serenity Browser - Multi-Platform Build Guide

This guide explains how to build Serenity Browser for all supported operating systems.

## Prerequisites

### System Dependencies

#### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install -y libwebkit2gtk-4.0-dev build-essential curl wget libssl-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev
```

#### Windows
- Visual Studio Build Tools or Visual Studio Community
- Install "C++ build tools" workload
- Include Windows 10/11 SDK

#### macOS
- Xcode or Xcode Command Line Tools
- WebKit (system provided)

### Development Tools

1. **Node.js** (v16 or later)
2. **Rust** (latest stable version)
3. **Tauri CLI**

## Installation

### Install Node.js
```bash
# Using nvm (recommended)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc
nvm install --lts
nvm use --lts
```

### Install Rust
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source ~/.cargo/env
```

### Install Tauri CLI
```bash
npm install -g @tauri-apps/cli
```

## Building

### Quick Build (All Platforms)
```bash
./build-all.sh
```

### Manual Build

#### 1. Install Dependencies
```bash
npm install --legacy-peer-deps
```

#### 2. Add Cross-Compilation Targets
```bash
rustup target add x86_64-pc-windows-gnu
rustup target add x86_64-apple-darwin
rustup target add aarch64-apple-darwin
rustup target add x86_64-unknown-linux-gnu
```

#### 3. Build for Each Platform

**Linux (current platform):**
```bash
npm run tauri:build
```

**Windows:**
```bash
npm run tauri:build -- --target x86_64-pc-windows-gnu
```

**macOS Intel:**
```bash
npm run tauri:build -- --target x86_64-apple-darwin
```

**macOS Apple Silicon:**
```bash
npm run tauri:build -- --target aarch64-apple-darwin
```

## Build Outputs

### Linux Packages
- **DEB Package**: `src-tauri/target/release/bundle/deb/serenity-browser_0.1.0_amd64.deb`
- **AppImage**: `src-tauri/target/release/bundle/appimage/Serenity Browser_0.1.0_amd64.AppImage`

### Windows Packages
- **NSIS Installer**: `src-tauri/target/x86_64-pc-windows-gnu/release/bundle/nsis/Serenity Browser_0.1.0_x64-setup.exe`
- **MSI Installer**: `src-tauri/target/x86_64-pc-windows-gnu/release/bundle/msi/Serenity Browser_0.1.0_x64_en-US.msi`
- **Portable**: `src-tauri/target/x86_64-pc-windows-gnu/release/Serenity Browser.exe`

### macOS Packages
- **DMG Installer**: `src-tauri/target/x86_64-apple-darwin/release/bundle/dmg/Serenity Browser_0.1.0_x64.dmg`
- **App Bundle**: `src-tauri/target/x86_64-apple-darwin/release/bundle/macos/Serenity Browser.app`
- **Apple Silicon DMG**: `src-tauri/target/aarch64-apple-darwin/release/bundle/dmg/Serenity Browser_0.1.0_aarch64.dmg`
- **Apple Silicon App**: `src-tauri/target/aarch64-apple-darwin/release/bundle/macos/Serenity Browser.app`

## GitHub Actions CI/CD

The project includes a GitHub Actions workflow (`.github/workflows/build.yml`) that automatically builds for all platforms on every push and pull request.

### Manual Trigger
You can also trigger builds manually from the GitHub Actions tab.

## Troubleshooting

### Missing C Compiler
If you get `linker 'cc' not found` error:
```bash
# Ubuntu/Debian
sudo apt install build-essential

# CentOS/RHEL
sudo yum groupinstall "Development Tools"

# macOS
xcode-select --install
```

### Missing System Libraries
If you get missing library errors:
```bash
# Ubuntu/Debian
sudo apt install libwebkit2gtk-4.0-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev

# CentOS/RHEL
sudo yum install webkit2gtk3-devel gtk3-devel libappindicator-gtk3-devel librsvg2-devel
```

### Cross-Compilation Issues
Make sure you have the correct target toolchain installed:
```bash
rustup target list --installed
```

### Build Cache Issues
Clear build cache if you encounter issues:
```bash
cargo clean
npm run tauri:build
```

## Development

### Run in Development Mode
```bash
npm run tauri:dev
```

### Frontend Only
```bash
npm run dev
```

## Distribution

### Code Signing

#### Windows
```bash
signtool sign /f certificate.p12 /p password /t http://timestamp.url "Serenity Browser.exe"
```

#### macOS
```bash
codesign --deep --force --verify --verbose --sign "Developer ID Application: Your Name" "Serenity Browser.app"
```

#### Linux
```bash
gpg --armor --detach-sign serenity-browser_0.1.0_amd64.deb
```

## System Requirements

### Windows
- **OS**: Windows 10 (1803+) or Windows 11
- **Architecture**: x64
- **Runtime**: Edge WebView2 (bundled)
- **Storage**: 200MB free space

### macOS
- **OS**: macOS 10.13 (High Sierra) or later
- **Architecture**: x64 or ARM64 (Apple Silicon)
- **Runtime**: System WebKit
- **Storage**: 150MB free space

### Linux
- **OS**: Ubuntu 18.04+, Debian 10+, Fedora 32+
- **Architecture**: x64
- **Runtime**: WebKitGTK 2.40+
- **Storage**: 180MB free space

## Support

For issues and questions:
1. Check the troubleshooting section above
2. Review the GitHub Issues
3. Check the Tauri documentation: https://tauri.app/
4. Check the Vite documentation: https://vitejs.dev/

## License

Copyright © 2024 Serenity Browser Team. All rights reserved.
